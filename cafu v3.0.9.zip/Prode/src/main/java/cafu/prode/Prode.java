/*

    Proyecto PRODE
    Autor cafu
    Versión 3.0.9

    Grupo 11
      Silvia Arias
      Carlos Fulqueris
      Paola Lombardo
      Adriana Van Den Dooren
      (Orden por apellido)

 */

package cafu.prode;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Prode {

    // declaraciones
    public static List <String> lineasResultados;
    public static List <String> lineasPredicciones;
    public static Collection <Partido> partidos = new ArrayList <>();
    public static Map <String, Integer> puntosJugador = new HashMap <>();
    public static TreeMap<String, String> faseJugadorPuntos = new TreeMap<>();

    public static void main(String[] args) throws SQLException {

        // lee archivo "resultados.csv" y "predicciones.csv"
        lineasResultados = ManageCSV.readRows(args[0]);
        lineasPredicciones = ManageCSV.readRows(args[1]);

        // carga "resultados" y "predicciones" en arreglos y, calcula aciertos y puntajes
        ManageCSV.loadResultados(lineasResultados, partidos);
        ManageCSV.loadPredicciones(lineasPredicciones, partidos, puntosJugador,
                                  faseJugadorPuntos);

        // muestra contenido de archivos "csv", aciertos y puntajes de jugadores
        Totales.showResultados(lineasResultados);
        Totales.showPredicciones(lineasPredicciones);
        Totales.showTotalesJugador(lineasResultados, lineasPredicciones, puntosJugador,
                             faseJugadorPuntos);
        Totales.showGanador(lineasResultados, lineasPredicciones, puntosJugador, faseJugadorPuntos);

    }

}

/*
        // implementación con SQL Server (cambiaron "root" y "nameServer")
        utilización de "import java.sql.SQLException"
        extensión de la clase con "throws SQLException"

        ManageSQL manageSQL = new ManageSQL();                      // genera instancia SQL
        manageSQL.Conecta();                                        // abre conexión
        manageSQL.loadResultados();                                 // resultados --> arreglos
        manageSQL.loadPredicciones(puntosJugador);                  // predicciones --> arreglos
        manageSQL.showTotals(puntosJugador);                        // muestra totales
        manageSQL.DesConecta();                                     // cierra conexión
*/

