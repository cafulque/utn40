package cafu.prode;

public class Predicciones {

    // declaraciones
    private final Partido partido;
    private final Equipo equipo;
    private final LEV resultado;

    // constructor
    public Predicciones(Partido partido, Equipo equipo, LEV resultado) {
        super();
        this.partido = partido;
        this.equipo = equipo;
        this.resultado = resultado;
    }

    // getters & setters
    public Partido getPartido() {
        return this.partido;
    }

    public Equipo getEquipo() {
        return this.equipo;
    }

    public LEV getResultado() {
        return this.resultado;
    }

    // calcula los puntos obtenidos por el jugador vs el resultado real
    public int puntos() {

        LEV resultadoReal = this.partido.resultado(this.equipo);

        if (this.resultado.equals(resultadoReal))
            return 1;
        else
            return 0;

    }

}

