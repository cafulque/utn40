package cafu.prode;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Totales {
    
    // declaraciones
    public static int count, puntos;
    public static boolean header;
    public static String ganador;
    public static String str, lineas, titulo;
    public static String campos[];

    // constructor
    public Totales() {
        super();
    }

    // método para mostrar el archivo "resultados.csv"
    public static void showResultados(List <String> lineasResultados) {

        header = true;

        System.out.println();
        lineas = "------------------------------------------------------------------------";
        titulo = "|                           <<< RESULTADOS >>>                           |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (String line : lineasResultados) {

            campos = line.split(";");
            str = String.format("| %4s | %-15s | %7s | %7s | %-15s | %7s |",
                  campos[0], campos[1], campos[2], campos[3], campos[4], campos[5]);
            System.out.println(str);

            if (header) {
                System.out.println("|" + lineas + "|");
                header = false;
            }

        }

        System.out.println("+" + lineas + "+");

    }

    // método para mostrar el archivo "predicciones.csv"
    public static void showPredicciones(List <String> lineasPredicciones) {

        header = true;

        System.out.println();
        lineas = "--------------------------------------------------------------------------------------";
        titulo = "|                                 <<< PREDICCIONES >>>                                 |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (String line : lineasPredicciones) {

            campos = line.split(";");

            str = String.format("| %-10s | %-15s |  %-6s | %-6s | %-6s | %-15s | %7s |",
                  campos[0], campos[1], campos[2], campos[3], campos[4], campos[5], campos[6]);

            System.out.println(str);

            if (header) {
                System.out.println("|" + lineas + "|");
                header = false;
            }

        }

        System.out.println("+" + lineas + "+");

    }

    // método para mostrar la cantidad de puntos obtenidos por jugador
    public static void showTotalesJugador(List <String> lineasResultados, List <String> lineasPredicciones,
                       Map <String, Integer> puntosJugador, TreeMap <String, String> faseJugadorPuntos) {

        count = 0;
        puntos = 0;
        header = true;

        System.out.println();
        lineas = "---------------------";
        titulo = "| < TOTALES JUGADOR > |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (String jugador : puntosJugador.keySet()) {

            if (header) {
                System.out.println("| Jugador    | Puntos |");
                System.out.println("|" + lineas + "|");
                header = false;
            }

//            Fase faseJugador = new Fase();
//            PuntosFaseJugador puntosFaseJugador = faseJugador.getPuntosFaseJugador();
            puntos = puntosJugador.get(jugador);

            str = String.format("| %-10s | %6d |", jugador, puntos);
            System.out.println(str);

            if (puntosJugador.get(jugador) > count) {
                count = puntosJugador.get(jugador);
                ganador = jugador;
            }

        }

        System.out.println("+" + lineas + "+");

    }

    // método para mostrar el nombre del jugador que ganó el prode
    public static void showGanador(List <String> lineasResultados, List <String> lineasPredicciones,
                       Map <String, Integer> puntosJugador, TreeMap <String, String> faseJugadorPuntos) {

        System.out.println();
        lineas = "---------------------";
        titulo = "|   <<< GANADOR >>>   |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");
        System.out.println(String.format("|       %-10s    |", ganador));
        System.out.println("+" + lineas + "+");

        System.out.println("\n");

    }

}

