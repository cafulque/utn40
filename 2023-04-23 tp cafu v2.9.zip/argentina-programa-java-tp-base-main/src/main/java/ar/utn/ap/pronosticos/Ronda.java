package ar.utn.ap.pronosticos;

public class Ronda {

    private int ronda;
    private String participante;
    private int puntos;
    private Partido partido;
    private Equipo equipo;
    private EnumResultado resultado;

    public Ronda () {
	super();
    }

    public Ronda (int ronda) {
	super();
	this.ronda = ronda;
    }

    public Ronda (String participante) {
	super();
        this.participante = participante;
    }

    public Ronda (int ronda, String participante, int puntos) {
	super();
	this.ronda = ronda;
        this.participante = participante;
        this.puntos = puntos;
    }

    public Ronda (int ronda, String participante, int puntos, Partido partido, Equipo equipo, EnumResultado resultado) {
	super();
	this.ronda = ronda;
        this.participante = participante;
        this.partido = partido;
	this.equipo = equipo;
	this.resultado = resultado;
    }

    public int getRonda () {
	return ronda;
    }

    public String getParticipante () {
	return participante;
    }

    public int getPuntos () {
	return puntos;
    }

    public Partido getPartido () {
	return partido;
    }

    public Equipo getEquipo () {
        return equipo;
    }

    public EnumResultado getResultado () {
	return this.resultado;
    }

    public void setRonda (int ronda) {
	this.ronda = ronda;
    }

    public void setParticipante (String participante) {
	this.participante = participante;
    }

    public void setPuntos (int puntos) {
	this.puntos = puntos;
    }

    public void setPartido (Partido partido) {
	this.partido = partido;
    }

    public void setEquipo (Equipo equipo) {
        this.equipo = equipo;
    }

}

