/*

    UTN 4.0 Java
    Proyecto cafu, grupo 11
    Autor cafu, v2.9

    **************************************
    ***  Contenido id�ntico a la v2.8  ***
    ***  con el agregado al final de   ***
    ***  "MAIN". Futuras acciones SQL  ***
    **************************************

*/

package ar.utn.ap.pronosticos;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MainTP {

    public static void main (String[] args) {

        // declaraciones
        Path pathResultados = Paths.get(args[0]);
        Path pathPronostico = Paths.get(args[1]);
        Collection <Partido> partidos = new ArrayList <Partido> ();
        List <String> lineasResultados = null;
        List <String> lineasPronostico = null;
        Ronda ronda = new Ronda();
        Equipo equipo = null;
        EnumResultado resultado = null;
        int puntos = 0;                                             // total puntos x pesona        
        boolean primera = true;

        // Lee archivo resultados
        try {
            lineasResultados = Files.readAllLines(pathResultados);
        } catch (IOException e) {
            System.out.println("No se pudo leer el archivo resultados!");
            System.out.println(e.getMessage());
            System.exit(1);
        }

        for (String lineaResultado : lineasResultados) {
            if (primera) {                                          // descarta header
                primera = false;
            } else {
                // Ronda; Argentina; 1; 2; Arabia Saudita (ejemplo)
                String[] campos = lineaResultado.split(";");
                Equipo equipo1 = new Equipo(campos[1]);
                Equipo equipo2 = new Equipo(campos[4]);
                Partido partido = new Partido(equipo1, equipo2);
                ronda.setRonda(Integer.parseInt(campos[0]));
                partido.setGolesEq1(Integer.parseInt(campos[2]));
                partido.setGolesEq2(Integer.parseInt(campos[3]));
                partidos.add(partido);
            }
        }

        // Lee archivo pronosticos
        try {
            lineasPronostico = Files.readAllLines(pathPronostico);
        } catch (IOException e) {
            System.out.println("No se pudo leer el archivo pronosticos!");
            System.out.println(e.getMessage());
            System.exit(1);
        }

        primera = true;

        for (String lineaPronostico : lineasPronostico) {
            if (primera) {                                          // descarta header
                primera = false;
            } else {
                // Mariana; Argentina; X; ; ; Arabia Saudita (ejemplo)
                String[] campos = lineaPronostico.split(";");
                Equipo equipo1 = new Equipo(campos[1]);
                Equipo equipo2 = new Equipo(campos[5]);
                Partido partido = null;

                for (Partido partidoCol : partidos) {
                    if (partidoCol.getEquipo1().getNombre().equals(equipo1.getNombre())
                        && partidoCol.getEquipo2().getNombre().equals(equipo2.getNombre())) {
                        partido = partidoCol;
                    }
                }

                if ("X".equals(campos[2])) {
                    equipo = equipo1;
                    resultado = EnumResultado.GANADOR;
                }

                if ("X".equals(campos[3])) {
                    equipo = equipo1;
                    resultado = EnumResultado.EMPATE;
                }

                if ("X".equals(campos[4])) {
                        equipo = equipo1;
                        resultado = EnumResultado.PERDEDOR;
                }

                Pronostico pronostico = new Pronostico(partido, equipo, resultado);
                puntos += pronostico.puntos();
                ronda.setParticipante(campos[0]);
                ronda.setPuntos(puntos);
            }
        }

        // muestra puntos
        System.out.println("Jugador\tPuntos");
        System.out.println(ronda.getParticipante() + "\t" + ronda.getPuntos());

    }
}




//////// AGREGADO PARA LA VERSION 2.9 //////////////////////

/*
    UTN 4.0 Java
    Proyecto cafu, grupo 11
    Autor cafu, v2.9

    Detalle "CONCEPTUAL" de las pr�ximas sentencias a incluir en la pr�xima versi�n "3.x".
    Se incluyen sentencias de MS-SQL, creaci�n de tablas, insert de datos y selects relacionados.

    Lamentablemente, la parte te�rica de SQL solo fue de sentencias b�sicas y en ning�n momento
    hubo pr�ctica. Tampoco se vio claramente c�mo se realizan las conexiones, desconexiones, el
    manejo de excepciones, chequeo de filas y columnas, variables de entorno, declaraci�n de
    variables y condicionales, storage procedure, etc.

    Debido a esto, solo se incluye en este espacio, tal como se menciona arriba, sentencias desde
    el punto de vista "CONCEPTUAL", por lo que las mismas pueden variar si se utiliza MySQL u otro
    RDBMS.


// sentencias de tablas

CREATE TABLE Pronosticos (
    id INT PRIMARY KEY,
    jugador VARCHAR(15),
    equipo1 VARCHAR(15),
    local CHAR(1),
    empate CHAR(1),
    visitante CHAR(1),
    equipo2 VARCHAR(15)
    );

INSERT INTO Pronosticos (id, jugador, equipo1, local, empate, visitante, equipo2) VALUES
    (1, 'Mariana', 'Argentina',      'X',  '',  '', 'Arabia Saudita'),
    (2, 'Mariana', 'Polonia,          '', 'X',  '', 'Mexico'),
    (3, 'Mariana', 'Argentina',      'X',  '',  '', 'Mexico'),
    (4, 'Mariana', 'Arabia Saudita',  '',  '', 'X', 'Polonia'),
    (5, 'Pedro',   'Argentina',      'X',  '',  '', 'Arabia Saudita'),
    (6, 'Pedro',   'Polonia',         '',  '', 'X', 'Mexico'),
    (7, 'Pedro',   'Argentina',      'X',  '',  '', 'Mexico'),
    (8, 'Pedro',   'Arabia Saudita',  '', 'X',  '', 'Polonia);

CREATE TABLE Resultados (
    id INT PRIMARY KEY,
    ronda INT,
    equipo1 VARCHAR(15),
    goles1 INT,
    goles2 INT,
    equipo2 VARCHAR(15)
    );

INSERT INTO Resultados (id, ronda, equipo1, goles1, goles2, equipo2) VALUES
    (1, 1, 'Argentina',      1, 2, 'Arabia Saudita'),
    (2, 1, 'Polonia',        0, 0, 'Mexico'),
    (3, 1, 'Argentina',      2, 0, 'Mexico'),
    (4, 1, 'Arabia Saudita', 0, 2, 'Polonia'),
    (5, 2, 'Argentina',      2, 1, 'Australia'),
    (6, 2, 'Francia',        3, 1, 'Polonia'),
    (7, 2, 'Pa�ses Bajos',   3, 1, 'Estados Unidos'),
    (8, 2, 'Jap�n',          1, 3, 'Croacia');


// sentencias de conexi�n/desconexi�n a la base de datos

import java.sql.Connection;				// biblioteca necesaria?
import java.sql.DriverManager;			// biblioteca necesaria?
import java.sql.SQLException;			// biblioteca necesaria?
import java.util.Arrays;

public class CnxDataBase {

    public Connection cnx = null;
    private String url = "jdbc:sqlserver://localhost:1433;databaseName=NameBataDase;";
    private String user = "UserDataBase";
    private String pass = "PassDataBase";

    try {
            conx = DriverManager.getConnection(url, user, pass);
            System.out.println("Successful connection!");
    } catch (SQLException e) {
            System.out.println("Error connecting to database!");
            e.printStackTrace();
    } finally {
            try {
                    if (cnx != null) cnx.close();
            } catch (SQLException e) {
                    System.out.println("Error closing database!");
                    e.printStackTrace();
            }
    }

}


// queries

Statement stat = cnx.createStatement();				// public
String aciertos[] = new String[5][2];				// 5 jugadores, 1 puntaje
boolean primera = true;													// first line
String curName = "", preName = "";
int puntaje = 0;

ResultSet res = stat.executeQuery("				// ejemplo de SELECT
    SELECT * FROM Pronosticos AS p, Resultados AS r
        WHERE p.equipo1 = r.equipo1 AND				// L=1, E=2, V=3
            IF (p.local = 'X') OR (p.empate = 'X') OR (p.visitante = 'X') THEN
                SET aciertos[ROW_NUMBER()-1][0] = p.jugador;
                SET aciertos[ROW_NUMBER()-1][1] = "1";
            END IF;
    ");

Arrays.sort(aciertos);

for (int acierto : aciertos)
    curName = aciertos[acierto][0];
    if (!primera) {
        preName = aciertos[acierto-1][0];
        if (curName.equals(preNeame)) {
            puntaje++;
        } else {
            System.out.println("Jugador/a " + preName + "\tPuntaje " + puntaje);
            puntaje = 0;
    } else {
        primera = false;
        puntaje++;
    }		
}

*/

