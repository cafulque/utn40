package ar.utn.ap.pronosticos;

public enum EnumResultado {
    GANADOR,
    PERDEDOR,
    EMPATE
}

