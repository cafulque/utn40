UTN 4.0 Java
Trabajo Integrador

Proyecto cafu, grupo 11, versión 2.8

Configuración de clases y objetos con colecciones.
Acceso a argumentos desde la consola (default a través de Path).
Getter y Setter accesorios algunos no utilizados pero generados para futuros usos.
No llegamos a utilizar SQL por clases incompletas y/o sin explicación adecuadas.
