-- Script Resultados.sql
use JavaTP;

-- drop table Resultados
if object_id ('dbo.Resultados', 'U') is not null
	drop table dbo.Resultados;
go

-- create table Resultados
create table Resultados (
	id int not null identity(1, 1) primary key,
	fase int not null,
	equipo1 varchar(15) not null,
	goles1 int not null,
	goles2 int not null,
	equipo2 varchar(15) not null,
	partido int not null,
	primary key (id)
);

-- insert rows to Resultados
set identity_insert Predicciones on;

insert into resultados (id, fase, equipo1, goles1, goles2, equipo2, partido) values
( '1', '1', 'Argentina',      '1', '2', 'Arabia Saudita' ,  '1'),
( '2', '1', 'Polonia',        '0', '0', 'Mexico'         ,  '2'),
( '3', '1', 'Argentina',      '2', '0', 'Mexico'         ,  '3'),
( '4', '1', 'Arabia Saudita', '0', '2', 'Polonia'        ,  '4'),
( '5', '2', 'Paises Bajos',   '3', '1', 'Estados Unidos' ,  '5'),
( '6', '2', 'Argentina',      '2', '1', 'Australia'      ,  '6'),
( '7', '2', 'Francia',        '3', '1', 'Polonia'        ,  '7'),
( '8', '2', 'Inglaterra',     '3', '0', 'Senegal'        ,  '8'),
( '9', '2', 'Japon',          '1', '3', 'Croacia'        ,  '9'),
('10', '2', 'Brasil',         '4', '1', 'Corea del Sur'  , '10'),
('11', '2', 'Marruecos',      '3', '0', 'España'         , '11'),
('12', '2', 'Portugal',       '6', '1', 'Suiza'          , '12'),
('13', '3', 'Croacia',        '4', '2', 'Brasil'         , '13'),
('14', '3', 'Paises Bajos',   '3', '4', 'Argentina'      , '14'),
('15', '3', 'Marruecos',      '1', '0', 'Portugal'       , '15'),
('16', '3', 'Inglaterra',     '1', '2', 'Francia'        , '16'),
('17', '4', 'Argentina',      '3', '0', 'Croacia'        , '17'),
('18', '4', 'Francia',        '2', '0', 'Marruecos'      , '18'),
('19', '5', 'Croacia',        '2', '1', 'Marruecos'      , '19'),
('20', '5', 'Argentina',      '4', '2', 'Francia'        , '20');

set identity_insert Predicciones off;
