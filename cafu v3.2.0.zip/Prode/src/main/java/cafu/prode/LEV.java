package cafu.prode;

// para comparar apuestas vs resultados
public enum LEV {

    LOCAL,
    EMPATE,
    VISITANTE

}

