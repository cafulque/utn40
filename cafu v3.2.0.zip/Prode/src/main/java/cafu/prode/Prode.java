/*

    Proyecto PRODE
    Autor cafu
    Versión 3.2.0

    Grupo 11
      Silvia Arias
      Carlos Fulqueris
      Paola Lombardo
      Adriana Van Den Dooren
      (Ordenado por apellido)

 */

package cafu.prode;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;


public class Prode {


    // variables
    public static Statement stmt = null;
    public static ResultSet filas = null;
    public static Connection conx = null;

    public static List <String> filasResultados = null;                         // para tablas SQL
    public static List <String> filasPredicciones = null;

    public static List <String> lineasResultados;                           // para archivos CSV
    public static List <String> lineasPredicciones;

    public static Collection <Partido> partidos = new ArrayList <>();
    public static Map <String, Integer> puntosJugador = new HashMap <>();
    public static TreeMap<String, String> jugadorFasePuntos = new TreeMap<>();


    public static void main(String[] args) throws SQLException {


// *** procesos para archivos CSV ***

        System.out.println();
        System.out.println("+------------------------------------------+");
        System.out.println("|     <<< PROCESO CON ARCHIVOS CSV >>>     |");
        System.out.println("+------------------------------------------+");
        
        // lee archivo "resultados.csv" y "predicciones.csv"
        lineasResultados = ManageCSV.readRows(args[0]);
        lineasPredicciones = ManageCSV.readRows(args[1]);

        // carga "resultados" y "predicciones" en arreglos, calcula aciertos y puntajes
        ManageCSV.loadResultados(lineasResultados, partidos);
        ManageCSV.loadPredicciones(lineasPredicciones, partidos, puntosJugador,
                                  jugadorFasePuntos);

        // muestra contenido de archivos "csv", aciertos y puntajes de jugadores
        Totales.showResultados(lineasResultados);
        Totales.showPredicciones(lineasPredicciones);

        // muestra puntos por jugador y fases
        Totales.showJugadorFasePuntos(jugadorFasePuntos);

        // muestra totales por jugador más bonus por aciertos de todos los partidos de una fase
        Totales.showTotalesJugador(lineasResultados, lineasPredicciones, puntosJugador,
                     jugadorFasePuntos);

        // muestra el jugador ganador de la competencia
        Totales.showGanador(lineasResultados, lineasPredicciones, puntosJugador, jugadorFasePuntos);


// *** procesos para tablas SQL ***

        System.out.println();
        System.out.println("+------------------------------------------+");
        System.out.println("|      <<< PROCESO CON TABLAS SQL >>>      |");
        System.out.println("+------------------------------------------+");

        ManageIO.ConnectSQL();

        // lee "resultados", carga en arreglos y muestra contenido
        filasResultados = ManageIO.readRowsSQL("resultados");
        Loader.Resultados(Const.NO_HEADER, filasResultados, partidos);
        Show.Resultados(filasResultados);

        // lee "predicciones", carga en arreglos, calcula aciertos y puntajes, y muestra contenido
        filasPredicciones = ManageIO.readRowsSQL("predicciones");
        Loader.Predicciones(Const.NO_HEADER, filasPredicciones, partidos, puntosJugador,
                                  jugadorFasePuntos);
        Show.Predicciones(filasPredicciones);

        // muestra puntos por jugador, fases y bonus por aciertos
        Show.JugadorFasePuntos(jugadorFasePuntos);

        // muestra totales por jugador
        Show.TotalesJugador(puntosJugador, jugadorFasePuntos);

        // muestra el jugador ganador de la competencia
        Show.Ganador();

        ManageIO.DisConnectSQL();
        System.out.println("\nApp closed successfully!\n\n");

    }

}

