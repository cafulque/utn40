package cafu.prode;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


public class Loader {


    // variables
    private static int bonus, count, qtyPartidos;
    private static int puntos, faseActual, faseAnterior;
    private static String jugadorActual, jugadorAnterior;
    private static String clave, valor;
    private static String campos[];

    public static Statement stmt = null;
    public static List <String> filas = null;
    public static Connection conx = null;
    //public static final Collection <Partido> partidos = new ArrayList <>();


    // constructor
    public Loader() {
        super();
    }


    // carga resultados en arreglos --> ej: "1;Argentina;1;2;Arabia Saudita;1"
    public static void Resultados(boolean header, List <String> filasResultados,
                                  Collection <Partido> partidos) {

        if (campos != null) Arrays.fill(campos, "");            // limpia arreglo

        for (String fila : filasResultados) {

            if (header) header = false;
            else {

                campos = fila.split(";");
                Equipo equipo1 = new Equipo(campos[2]);
                Equipo equipo2 = new Equipo(campos[5]);
                Partido partido = new Partido(equipo1, equipo2);
                partido.setGolesEq1(Integer.parseInt(campos[3]));
                partido.setGolesEq2(Integer.parseInt(campos[4]));
                partido.setFase(Integer.parseInt(campos[1]));
                partidos.add(partido);

            }

        }

    }


    // carga predicciones en arreglos --> ej: "Mariana;Argentina;X;;;Arabia Saudita;1"
    public static void Predicciones(boolean header, List <String> filasPredicciones,
                                    Collection <Partido> partidos,
                                    Map <String, Integer> puntosJugador,
                                    TreeMap <String, String> jugadorFasePuntos) {

        faseAnterior = 1;                                           // corte de control
        qtyPartidos = 0;                                            // partidos/fase
        count = 0;                                                  // cuenta partidos
        jugadorAnterior = "";                                       // Map --> clave, valor

        if (campos != null) Arrays.fill(campos, "");          // limpia arreglo

        for (String fila : filasPredicciones) {

            if (header) header = false;
            else {

                campos = fila.split(";");
                jugadorActual = campos[1];
                Equipo equipo1 = new Equipo(campos[2]);
                Equipo equipo2 = new Equipo(campos[6]);
                Partido partido = null;

                for (Partido partidoCol : partidos) {
                    if (partidoCol.getEquipo1().getNombre().equals(equipo1.getNombre())
                        && partidoCol.getEquipo2().getNombre().equals(equipo2.getNombre())) {
                        partido = partidoCol;
                        faseActual = partidoCol.getFase();                        
                    }
                }

                Equipo equipo = equipo1;
                LEV resultado = null;
                if ("X".equals(campos[3])) resultado = LEV.LOCAL;
                if ("X".equals(campos[4])) resultado = LEV.EMPATE;
                if ("X".equals(campos[5])) resultado = LEV.VISITANTE;

                // suma puntos x jugador
                Predicciones forecast = new Predicciones(partido, equipo, resultado);
                puntos = forecast.puntos();                                 // puntos ganados/partido

                if (puntosJugador.containsKey(jugadorActual)) {
                    puntosJugador.put(jugadorActual, puntosJugador.get(jugadorActual)
                                        + puntos);
                } else {
                    puntosJugador.put(jugadorActual, puntos);
                }

                if (faseActual != faseAnterior) {

                    clave = jugadorAnterior + ";" + faseAnterior + ";" + qtyPartidos;

                    if (count == qtyPartidos) {
                        valor = count + ";" + Const.BONUS;
                    } else {
                        valor = count + ";" + Const.PUNTOS_APUESTA;
                    }

                    jugadorFasePuntos.put(clave, valor);
                    count = puntos;
                    qtyPartidos = 1;
                    faseAnterior = faseActual;

                } else {

                    count += puntos;
                    qtyPartidos++;
                    jugadorAnterior = jugadorActual;

                }

            }

        }

        clave = jugadorAnterior + ";" + faseAnterior + ";" + qtyPartidos;

        if (count == qtyPartidos) valor = count + ";" + Const.BONUS;
                                  valor = count + ";" + Const.PUNTOS_APUESTA;

        jugadorFasePuntos.put(clave, valor);

        // agrega bonus al puntaje general
        for (Map.Entry<String, String> line : jugadorFasePuntos.entrySet()) {

            clave = line.getKey();                                      // clave
            campos = clave.split(";");                             // jugador;fase;partidos(acum)
            jugadorActual = campos[0];                                  // jugador actual

            campos = line.getValue().split(";");                   // valor
            bonus = Integer.parseInt(campos[1]);                        // puntos;bonus

            puntosJugador.put(jugadorActual, puntosJugador.get(jugadorActual) + bonus);

        }

    }

}

