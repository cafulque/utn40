/*  TODO
    agregar un método para la liberación de recursos

*/

package cafu.prode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class ManageSQL {

    // declaraciones
    private static boolean header;
    private static int bonus, count, qtyPartidos;
    private static int puntos, faseActual, faseAnterior;
    private static String jugadorActual, jugadorAnterior;
    private static String clave, valor, select;
    private static String campos[];

    public static Statement stmt = null;
    public static List <String> filas = null;
    public static Connection conx = null;
    public static final Collection <Partido> partidos = new ArrayList <>();

    // constructor
    public ManageSQL() {
        super();
    }

    // conexion a SQL Server
    public static void Conecta() {

        try {                                                               // abre conexión
            conx = DriverManager.getConnection(Const.URL, Const.USER, Const.PASS);
            System.out.println("Conexión exitosa a " + Const.DB + "!");
        } catch (SQLException ex) {
            System.out.println("Imposible acceder a la base de datos \"" + Const.DB + "\"");
            System.out.println("URL " + Const.URL);
            System.out.println("Por favor, comuníquese con el personal de sistemas!");
            System.out.println("Exception: " + ex + "\n\n");
            System.exit(100);
        }

    }

    // desconexión de SQL Server
    public static void DesConecta() {

        try {                                                               // cierra conexión
            conx.close();
            System.out.println("Desconexión exitosa de " + Const.DB + "!");
        } catch (SQLException ex) {
            System.out.println("Imposible cerrar la base de datos \"" + Const.DB + "\"");
            System.out.println("URL " + Const.URL);
            System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
            System.out.println("Exception: " + ex + "\n\n");
            System.exit(200);
        } finally {
            try {
                if (filas != null) filas.close();                           // libera recursos
                if (stmt != null) stmt.close();
                if (conx != null) conx.close();
            } catch (SQLException ex) {
                System.out.println("Imposible liberar recursos de la base de datos \"" + Const.DB + "\"");
                System.out.println("URL " + Const.URL);
                System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
                System.out.println("Exception: " + ex + "\n\n");
                System.exit(300);
            }
        }

    }

    // lee todas las filas de la tabla
    public static List <String> readRows(String tabla) throws SQLException {

        // revisar ************************************************************************
        select = "SELECT * FROM " + tabla + ";";                            // select/tabla

        try {
            conx = DriverManager.getConnection(Const.URL, Const.USER, Const.PASS);
            stmt = conx.createStatement();                                  // instancia a SQL
            filas = stmt.executeQuery(select);

/*
TODO: devolver un List <String> --> lineasResultados/lineasPredicciones
List<Empleado> listaEmpleados = new ArrayList<>();
Statement stmt = conn.createStatement();
ResultSet rs = stmt.executeQuery("SELECT nombre, apellido FROM empleados");
while (rs.next()) {
    String nombre = rs.getString("nombre");
    String apellido = rs.getString("apellido");
    Empleado empleado = new Empleado(nombre, apellido);
    listaEmpleados.add(empleado);
}
rs.close();
stmt.close();
conn.close(); // se cierra la conexión            
*/            

        } catch (SQLException ex) {
            System.out.println("Imposible instanciar o leer la base de datos \"" + Const.DB + "\"");
            System.out.println("URL " + Const.URL);
            System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
            System.out.println("Exception: " + ex + "\n\n");
            System.exit(200);
        } finally {
            try {
                if (filas != null) filas.close();                           // libera recursos
                if (stmt != null) stmt.close();
                if (conx != null) conx.close();
            } catch (SQLException ex) {
                System.out.println("Imposible liberar recursos de la base de datos \"" + Const.DB + "\"");
                System.out.println("URL " + Const.URL);
                System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
                System.out.println("Exception: " + ex + "\n\n");
                System.exit(300);
            }
        }

        return filas;

    }

    // carga resultados en arreglos
    public static void loadResultados(ResultSet filas, Collection <Partido> partidos)
           throws SQLException {

        header = true;

        while (filas.next()) {

            if (header) header = false;
            else {
                Equipo equipo1 = new Equipo(filas.getString("equipo1"));
                Equipo equipo2 = new Equipo(filas.getString("equipo2"));
                Partido partido = new Partido(equipo1, equipo2);
                partido.setFase(Integer.parseInt(filas.getString("fase")));
                partido.setGolesEq1(Integer.parseInt(filas.getString("goles1")));
                partido.setGolesEq2(Integer.parseInt(filas.getString("goles2")));
                partidos.add(partido);
            }

        }

    }

    // carga predicciones en arreglos
    public static void loadPredicciones(ResultSet filas, Collection <Partido> partidos,
                                 Map <String, Integer> puntosJugador,
                                 TreeMap <String, String> jugadorFasePuntos) throws SQLException {

        header = true;

        while (filas.next()) {

            if (header) header = false;
            else {

                Equipo equipo1 = new Equipo(filas.getString("equipo1"));
                Equipo equipo2 = new Equipo(filas.getString("equipo2"));
                Partido partido = null;

                for (Partido partidoCol : partidos) {
                    if (partidoCol.getEquipo1().getNombre().equals(equipo1.getNombre())
                        && partidoCol.getEquipo2().getNombre().equals(equipo2.getNombre())) {
                        partido = partidoCol;
                    }
                }

                Equipo equipo = equipo1;
                LEV resultado = null;
                if ("X".equals(filas.getString("local")))
                    resultado = LEV.LOCAL;
                if ("X".equals(filas.getString("empate")))
                    resultado = LEV.EMPATE;
                if ("X".equals(filas.getString("visitante")))
                    resultado = LEV.VISITANTE;

                // suma puntos x jugador
                Predicciones forecast = new Predicciones(partido, equipo, resultado);
                jugadorActual = filas.getString("jugador");
                puntos = forecast.puntos();                                 // puntos ganados/partido

                if (puntosJugador.containsKey(jugadorActual)) {
                    puntosJugador.put(jugadorActual, puntosJugador.get(jugadorActual)
                                        + puntos);
                } else {
                    puntosJugador.put(jugadorActual, puntos);
                }

                if (faseActual != faseAnterior) {

                    clave = jugadorAnterior + ";" + faseAnterior + ";" + qtyPartidos;

                    if (count == qtyPartidos) {
                        valor = count + ";" + Const.BONUS;
                    } else {
                        valor = count + ";" + Const.PUNTOS_APUESTA;
                    }

                    jugadorFasePuntos.put(clave, valor);
                    count = puntos;
                    qtyPartidos = 1;
                    faseAnterior = faseActual;

                } else {

                    count += puntos;
                    qtyPartidos++;
                    jugadorAnterior = jugadorActual;

                }

            }

        }

        clave = jugadorAnterior + ";" + faseAnterior + ";" + qtyPartidos;

        if (count == qtyPartidos) valor = count + ";" + Const.BONUS;
                                  valor = count + ";" + Const.PUNTOS_APUESTA;

        jugadorFasePuntos.put(clave, valor);

        // agrega bonus al puntaje general
        for (Map.Entry<String, String> line : jugadorFasePuntos.entrySet()) {

            clave = line.getKey();                                      // clave
            campos = clave.split(";");                             // jugador;fase;partidos(acum)
            jugadorActual = campos[0];                                  // jugador actual

            campos = line.getValue().split(";");                   // valor
            bonus = Integer.parseInt(campos[1]);                        // puntos;bonus

            puntosJugador.put(jugadorActual, puntosJugador.get(jugadorActual) + bonus);

        }

    }

    // muestra contenidos y totales de jugadores
    public void showTotals(Map <String, Integer> puntosJugador) throws SQLException {

        int count = 0, puntos;
        String str;
        String ganador = "";

        stmt = conx.createStatement();                                      // instancia a SQL
        
        header = true;
        filas = stmt.executeQuery("select * from resultados");
        System.out.println("\n/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬ Resultados ¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\");

        while (filas.next()) {
            if (header) header = false;
            else {
                str = String.format("%4s  %-15s %7s  %7s  %-15s  %7s",
                filas.getString("fase"), filas.getString("equipo1"),
                filas.getString("goles1"), filas.getString("goles2"),
                filas.getString("equipo2"), filas.getString("partido"));
                System.out.println(str);
            }
        }

        header = true;
        filas = stmt.executeQuery("select * from predicciones");
        System.out.println("\n/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬ Predicciones ¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\");

        while (filas.next()) {
            if (header) header = false;
            else {
      
                str = String.format("%-10s  %-15s  %-6s  %-6s  %-6s  %-15s  %7s",
                filas.getString("jugador"), filas.getString("equipo1"),
                filas.getString("local"), filas.getString("empate"),
                filas.getString("visitante"), filas.getString("equipo2"),
                filas.getString("partido"));
                System.out.println(str);
            }
        }

        System.out.println("\n/¬/¬ Totales x Jugador ¬\\¬\\");

        for (String jClave : puntosJugador.keySet()) {
            puntos = puntosJugador.get(jClave);
            str = String.format("%10s obtuvo %d punto", jClave, puntos);
            if (puntos > 1) str += "s";
            System.out.println(str);
            if (puntosJugador.get(jClave) > count) {
                count = puntosJugador.get(jClave);
                ganador = jClave;
            }
        }

        System.out.println("\n/¬/¬/¬/¬/¬/¬ Ganador ¬\\¬\\¬\\¬\\¬\\¬\\");
        System.out.println("\"" + ganador + "\" ganó las predicciones!\n\n");
    }

}

