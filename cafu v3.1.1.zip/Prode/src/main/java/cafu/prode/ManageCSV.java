package cafu.prode;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.Map;
import java.util.List;
import java.util.TreeMap;

public class ManageCSV {

    // declaraciones
    public static List <String> lineasArchivo;

    // constructor
    public ManageCSV() {
        super();
    }

    // lee todas las filas de un archivo "csv"
    public static List <String> readRows(String archivo) {

        try {
            lineasArchivo = Files.readAllLines(Paths.get(archivo));
        } catch (IOException ex) {
            System.out.println("Imposible leer el archivo " + archivo);
            System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
            System.exit(100);
        }

        return lineasArchivo;
    }

    // carga "resultados" en arreglos --> 1;Argentina;1;2;Arabia Saudita;1
    public static void loadResultados(List <String> lineasArchivo, Collection <Partido> partidos) {

        boolean header = true;
        String campos[];

        for (String fila : lineasArchivo) {

            if (header) header = false;
            else {
                campos = fila.split(";");
                Equipo equipo1 = new Equipo(campos[1]);
                Equipo equipo2 = new Equipo(campos[4]);
                Partido partido = new Partido(equipo1, equipo2);
                partido.setGolesEq1(Integer.parseInt(campos[2]));
                partido.setGolesEq2(Integer.parseInt(campos[3]));
                partido.setFase(Integer.parseInt(campos[0]));
                partidos.add(partido);
            }

        }

    }

    // carga "predicciones" en arreglos --> "Mariana;Argentina;X;;;Arabia Saudita;1"
    public static void loadPredicciones(List <String> lineasArchivo, Collection <Partido> partidos, 
                                        Map <String, Integer> puntosJugador,
                                        TreeMap <String, String> jugadorFasePuntos) {

        boolean header = true;
        int faseActual = 0, faseAnterior = 1, qtyPartidos = 0;          // qtyPartidos = partidos/fase
        int puntos, count = 0, bonus;                                   // acierto/partido
        String clave, valor, jugadorActual, jugadorAnterior = "";       // Map --> clave, valor
        String campos[];

        for (String fila : lineasArchivo) {                             // Mariana;Argentina;X;;;Arabia Saudita;1

            if (header) header = false;
            else {

                campos = fila.split(";");                          // predicciones
                jugadorActual = campos[0];
                Equipo equipo1 = new Equipo(campos[1]);
                Equipo equipo2 = new Equipo(campos[5]);
                Partido partido = null;

                for (Partido partidoCol : partidos) {                   // loop resultados
                    if (partidoCol.getEquipo1().getNombre().equals(equipo1.getNombre())
                        && partidoCol.getEquipo2().getNombre().equals(equipo2.getNombre())) {
                        partido = partidoCol;
                        faseActual = partidoCol.getFase();
                    }
                }

                Equipo equipo = equipo1;
                LEV resultado = null;
                if ("X".equals(campos[2])) resultado = LEV.LOCAL;
                if ("X".equals(campos[3])) resultado = LEV.EMPATE;
                if ("X".equals(campos[4])) resultado = LEV.VISITANTE;

                // acumula puntos por jugador
                Predicciones forecast = new Predicciones(partido, equipo, resultado);
                puntos = forecast.puntos();                             // puntos ganados/partido

                if (puntosJugador.containsKey(jugadorActual)) {
                    puntosJugador.put(jugadorActual, puntosJugador.get(jugadorActual) + puntos);
                } else {
                    puntosJugador.put(jugadorActual, puntos);
                }

                if (faseActual != faseAnterior) {

                    clave = jugadorAnterior + ";" + faseAnterior + ";" + qtyPartidos;

                    if (count == qtyPartidos) {
                        valor = count + ";" + Const.BONUS;
                    } else {
                        valor = count + ";" + Const.PUNTOS_APUESTA;
                    }

                    jugadorFasePuntos.put(clave, valor);
                    count = puntos;
                    qtyPartidos = 1;
                    faseAnterior = faseActual;

                } else {

                    count += puntos;
                    qtyPartidos++;
                    jugadorAnterior = jugadorActual;

                }

            }

        }

        clave = jugadorAnterior + ";" + faseAnterior + ";" + qtyPartidos;

        if (count == qtyPartidos) {
            valor = count + ";" + Const.BONUS;
        } else {
            valor = count + ";" + Const.PUNTOS_APUESTA;
        }

        jugadorFasePuntos.put(clave, valor);

        // agrega bonus al puntaje general
        for (Map.Entry<String, String> line : jugadorFasePuntos.entrySet()) {

            clave = line.getKey();                                      // clave
            campos = clave.split(";");                             // jugador;fase;partidos(acum)
            jugadorActual = campos[0];                                  // jugador actual

            campos = line.getValue().split(";");                   // valor
            bonus = Integer.parseInt(campos[1]);                        // puntos;bonus

            puntosJugador.put(jugadorActual, puntosJugador.get(jugadorActual) + bonus);

        }

    }

}

