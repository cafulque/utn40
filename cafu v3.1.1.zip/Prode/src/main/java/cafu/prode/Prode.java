/*

    Proyecto PRODE
    Autor cafu
    Versión 3.1.1

    Grupo 11
      Silvia Arias
      Carlos Fulqueris
      Paola Lombardo
      Adriana Van Den Dooren
      (Ordenado por apellido)

 */

package cafu.prode;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;

public class Prode {

    // declaraciones
    public static Statement stmt = null;
    public static ResultSet filas = null;
    public static Connection conx = null;

    public static ResultSet filasResultados = null;                         // para tablas SQL
    public static ResultSet filasPredicciones = null;

    public static List <String> lineasResultados;                           // para archivos CSV
    public static List <String> lineasPredicciones;

    public static Collection <Partido> partidos = new ArrayList <>();
    public static Map <String, Integer> puntosJugador = new HashMap <>();
    public static TreeMap<String, String> jugadorFasePuntos = new TreeMap<>();

    public static void main(String[] args) throws SQLException {




    // *** procesos para archivos CSV ***
        // lee archivo "resultados.csv" y "predicciones.csv"
        lineasResultados = ManageCSV.readRows(args[0]);
        lineasPredicciones = ManageCSV.readRows(args[1]);

        // carga "resultados" y "predicciones" en arreglos, calcula aciertos y puntajes
        ManageCSV.loadResultados(lineasResultados, partidos);
        ManageCSV.loadPredicciones(lineasPredicciones, partidos, puntosJugador,
                                  jugadorFasePuntos);

        // muestra contenido de archivos "csv", aciertos y puntajes de jugadores
        Totales.showResultados(lineasResultados);
        Totales.showPredicciones(lineasPredicciones);

        // muestra puntos por jugador y fases
        Totales.showJugadorFasePuntos(jugadorFasePuntos);

        // muestra totales por jugador más bonus por aciertos de todos los partidos de una fase
        Totales.showTotalesJugador(lineasResultados, lineasPredicciones, puntosJugador,
                     jugadorFasePuntos);

        // muestra el jugador ganador de la competencia
        Totales.showGanador(lineasResultados, lineasPredicciones, puntosJugador, jugadorFasePuntos);




// *** procesos para tablas SQL ***

/*        ManageSQL manageSQL = new ManageSQL();                              // instancia SQL        
        ManageSQL.Conecta();                                                // abre conexión        

        // lee las filas de las tablas "resultados" y "predicciones"
        filasResultados = ManageSQL.readRows("resultados");
        filasPredicciones = ManageSQL.readRows("predicciones");

        ManageSQL.DesConecta();                                             // cierra conexión

// ***** reemplazar filasResultados por lineasResultados
// ***** reemplazar método ManageCSV y ManageSQL por ManageFile (carga resultados y predicciones)
        // carga "resultados" y "predicciones" en arreglos, calcula aciertos y puntajes
        ManageFile.loadResultados(filasResultados, partidos);
        ManageFile.loadPredicciones(filasPredicciones, partidos, puntosJugador,
                                  jugadorFasePuntos);

// ***** reemplazar filasResultados por lineasResultados
        // muestra contenido de las tablas, aciertos y puntajes de jugadores
        Totales.showResultados(filasResultados);
        Totales.showPredicciones(filasPredicciones);

        // muestra puntos por jugador y fases
        Totales.showJugadorFasePuntos(jugadorFasePuntos);

        // muestra totales por jugador más bonus por aciertos de todos los partidos de una fase
        Totales.showTotalesJugador(lineasResultados, lineasPredicciones, puntosJugador,
                     jugadorFasePuntos);

        // muestra el jugador ganador de la competencia
        Totales.showGanador(lineasResultados, lineasPredicciones, puntosJugador, jugadorFasePuntos);

*/
        System.out.println("\nApp closed successfully!\n\n");

    }

}

/*
        // implementación con SQL Server (cambiaron "root" y "nameServer")
        utilización de "import java.sql.SQLException"
        extensión de la clase con "throws SQLException"

        ManageSQL manageSQL = new ManageSQL();                      // genera instancia SQL
        manageSQL.Conecta();                                        // abre conexión
        manageSQL.loadResultados();                                 // resultados --> arreglos
        manageSQL.loadPredicciones(puntosJugador);                  // predicciones --> arreglos
        manageSQL.showTotals(puntosJugador);                        // muestra totales
        manageSQL.DesConecta();                                     // cierra conexión
*/

