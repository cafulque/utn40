package cafu.prode;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class TotalesSQL {

    private static int count, puntos, partido;
    private static boolean header;

    private static String jugadorActual, jugadorAnterior;
    private static String clave, valor, faseActual;
    private static String lineas, titulo;
    private static String campos[];

    public static ResultSet filasResultados = null;
    public static ResultSet filasPredicciones = null;

    // método para mostrar la tabla "resultados"
    public static void showResultados(ResultSet filas) throws SQLException {

        header = true;

        System.out.println();
        lineas = "------------------------------------------------------------------------";
        titulo = "|                           <<< RESULTADOS >>>                           |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        while (filas.next()) {

            System.out.println(String.format("| %4s | %-15s | %7s | %7s | %-15s | %7s |",
              filas.getString("fase"), filas.getString("equipo1"),
              filas.getString("goles1"), filas.getString("goles2"),
              filas.getString("equipo2"), filas.getString("partido")));

            if (header) {
                System.out.println("|" + lineas + "|");
                header = false;
            }

        }

        System.out.println("+" + lineas + "+");

    }

    // método para mostrar la tabla "predicciones"
    public static void showPredicciones(ResultSet filas) throws SQLException {

        header = true;

        System.out.println();
        lineas = "--------------------------------------------------------------------------------------";
        titulo = "|                                 <<< PREDICCIONES >>>                                 |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        while (filas.next()) {

            System.out.println(String.format("| %4s | %-15s | %7s | %7s | %-15s | %7s |",
              filas.getString("jugador"), filas.getString("equipo1"),
              filas.getString("local"), filas.getString("empate"),
              filas.getString("visitante"), filas.getString("equipo2"),
              filas.getString("partido")));

            if (header) {
                System.out.println("|" + lineas + "|");
                header = false;
            }

        }

        System.out.println("+" + lineas + "+");

    }

    // método para mostrar el detalle de puntos obtenidos por cada jugador y fases
    public static void showJugadorFasePuntos(TreeMap <String, String> jugadorFasePuntos) {

        count = 0;
        puntos = 0;
        header = true;

        System.out.println();
        lineas = "------------------------------------";
        titulo = "| <<< PUNTOS POR JUGADOR Y FASES >>> |";
        System.out.println("+" + lineas + "+");
        System.out.println(titulo);
        System.out.println("|" + lineas + "|");

        for (Map.Entry<String, String> line : jugadorFasePuntos.entrySet()) {

            clave = line.getKey();                                      // jugador;fase;partidos(acum)
            campos = clave.split(";");
            jugadorActual = campos[0];
            faseActual = campos[1];
            partido = Integer.parseInt(campos[2]);

            valor = line.getValue();                                    // acumulador de puntos
            campos = valor.split(";");
            
            if (header) {
                System.out.println("| Jugador    | Fase | Puntos | Bonus |");
                System.out.println("|" + lineas + "|");
                jugadorAnterior = jugadorActual;
                header = false;
            }

            if (!jugadorActual.equals(jugadorAnterior)) {
                System.out.println("+" + lineas + "+");
                jugadorAnterior = jugadorActual;
            }

            System.out.println(String.format("| %-10s | %4s |  %5s | %5s |",
                             jugadorActual, faseActual, campos[0], campos[1]));

        }

        System.out.println("+" + lineas + "+");

    }

    
    
    
    
    
    
    

}
