package cafu.prode;

import java.sql.SQLException;
import org.junit.jupiter.api.Test;

public class ProdeTest {

    // constructor
    public ProdeTest() {
    }

    // @throws Exceptions
    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }

    // Test del método Prode (main)
    // @org.junit.jupiter.api.Test
    @Test
    public void testMain() throws SQLException {
        System.out.println("main");
        String[] args = {"D:/cafu/Training/Tecnology/Java/TP/cafu/Prode/src/main/java/cafu/prode/Resultados.csv",
                         "D:/cafu/Training/Tecnology/Java/TP/cafu/Prode/src/main/java/cafu/prode/Predicciones.csv"};
        Prode.main(args);
    }

}

/*
    unused imports
    import org.junit.jupiter.api.AfterEach;
    import org.junit.jupiter.api.AfterAll;
    import org.junit.jupiter.api.BeforeEach;
    import org.junit.jupiter.api.BeforeAll;
    import static org.junit.jupiter.api.Assertions.*;
*/