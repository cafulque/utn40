package cafu.prode;

public enum LEV {

    LOCAL,
    EMPATE,
    VISITANTE

}

