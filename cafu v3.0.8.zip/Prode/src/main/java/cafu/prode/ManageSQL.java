package cafu.prode;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ManageSQL {

    // variables de entorno
    boolean header;
    String jugador;
    String db = "JavaTP";
    String user = "root";
    String pass = "root";
    Statement stmt = null;
    ResultSet filas = null;
    Connection conx = null;
    private static final Collection <Partido> partidos = new ArrayList <>();

    // SQL Server
    // String url = "jdbc:sqlserver://localhost:1433;encrypt=true;databaseName="+ db +";integratedSecurity=true";

    // MySQLdatabaseName=
    String url = "jdbc:mysql://localhost:3306/JavaTP";
    String drv = "com.mysql.cj.jdbc.Driver";

    public ManageSQL() {
        super();
    }

    public Connection Conecta() {

        try {
            Class.forName(drv);
            conx = DriverManager.getConnection(url, user, pass);
            System.out.println("Conectado a " + db + "!");
        } catch (SQLException ex) {
            System.out.println("Imposible acceder a la base de datos \"" + db + "\"");
            System.out.println("URL " + url);
            System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
            System.exit(100);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ManageSQL.class.getName()).log(Level.SEVERE, null, ex);
        }

        return conx;

    }

    public void DesConecta() {

        try {
            conx.close();                                           // cierra conexión
        } catch (SQLException ex) {
            System.out.println("Imposible cerrar la base de datos \"" + db + "\"");
            System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
            System.out.println(ex.getMessage());
            System.exit(200);
        } finally {
            try {
                if (filas != null) filas.close();                   // libera recursos
                if (stmt != null) stmt.close();
                if (conx != null) conx.close();
            } catch (SQLException ex) {
                System.out.println("Imposible liberar recursos de la base de datos \"" + db + "\"");
                System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
                System.out.println(ex.getMessage());
                System.exit(300);
            }
        }

    }

    // carga resultados en arreglos
    public void loadResultados() throws SQLException {

        header = true;
        stmt = conx.createStatement();                              // instancia a SQL
        filas = stmt.executeQuery("select * from resultados");

        while (filas.next()) {

            if (header) header = false;
            else {
                Equipo equipo1 = new Equipo(filas.getString("equipo1"));
                Equipo equipo2 = new Equipo(filas.getString("equipo2"));
                Partido partido = new Partido(equipo1, equipo2);
                partido.setFase(Integer.parseInt(filas.getString("fase")));
                partido.setGolesEq1(Integer.parseInt(filas.getString("goles1")));
                partido.setGolesEq2(Integer.parseInt(filas.getString("goles2")));
                partidos.add(partido);
            }

        }

    }

    // carga predicciones en arreglos
    public void loadPredicciones(Map <String, Integer> puntosJugador) throws SQLException {

        header = true;
        stmt = conx.createStatement();                              // instancia a SQL
        filas = stmt.executeQuery("select * from predicciones");

        while (filas.next()) {

            if (header) header = false;
            else {

                Equipo equipo1 = new Equipo(filas.getString("equipo1"));
                Equipo equipo2 = new Equipo(filas.getString("equipo2"));
                Partido partido = null;

                for (Partido partidoCol : partidos) {
                    if (partidoCol.getEquipo1().getNombre().equals(equipo1.getNombre())
                        && partidoCol.getEquipo2().getNombre().equals(equipo2.getNombre())) {
                        partido = partidoCol;
                    }
                }

                Equipo equipo = null;
                LEV resultado = null;

                if ("X".equals(filas.getString("local"))) {
                    equipo = equipo1;
                    resultado = LEV.LOCAL;
                }

                if ("X".equals(filas.getString("empate"))) {
                    equipo = equipo1;
                    resultado = LEV.EMPATE;
                }

                if ("X".equals(filas.getString("visitante"))) {
                    equipo = equipo1;
                    resultado = LEV.VISITANTE;
                }

                // suma puntos x jugador
                Predicciones forecast = new Predicciones(partido, equipo, resultado);
                jugador = filas.getString("jugador");

                if (puntosJugador.containsKey(jugador)) {
                    puntosJugador.put(jugador, puntosJugador.get(jugador) + forecast.puntos());
                } else {
                    puntosJugador.put(jugador, forecast.puntos());
                }
            }

        }

    }

    public void showTotals(Map <String, Integer> puntosJugador) throws SQLException {

        int count = 0, puntos;
        String str;
        String ganador = "";

        stmt = conx.createStatement();                              // instancia a SQL
        
        header = true;
        filas = stmt.executeQuery("select * from resultados");
        System.out.println("\n/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬ Resultados ¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\");

        while (filas.next()) {
            if (header) header = false;
            else {
                str = String.format("%4s  %-15s %7s  %7s  %-15s  %7s",
                filas.getString("fase"), filas.getString("equipo1"),
                filas.getString("goles1"), filas.getString("goles2"),
                filas.getString("equipo2"), filas.getString("partido"));
                System.out.println(str);
            }
        }

        header = true;
        filas = stmt.executeQuery("select * from predicciones");
        System.out.println("\n/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬/¬ Predicciones ¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\¬\\");

        while (filas.next()) {
            if (header) header = false;
            else {
      
                str = String.format("%-10s  %-15s  %-6s  %-6s  %-6s  %-15s  %7s",
                filas.getString("jugador"), filas.getString("equipo1"),
                filas.getString("local"), filas.getString("empate"),
                filas.getString("visitante"), filas.getString("equipo2"),
                filas.getString("partido"));
                System.out.println(str);
            }
        }

        System.out.println("\n/¬/¬ Totales x Jugador ¬\\¬\\");

        for (String jClave : puntosJugador.keySet()) {
            puntos = puntosJugador.get(jClave);
            str = String.format("%10s obtuvo %d punto", jClave, puntos);
            if (puntos > 1) str += "s";
            System.out.println(str);
            if (puntosJugador.get(jClave) > count) {
                count = puntosJugador.get(jClave);
                ganador = jClave;
            }
        }

        System.out.println("\n/¬/¬/¬/¬/¬/¬ Ganador ¬\\¬\\¬\\¬\\¬\\¬\\");
        System.out.println("\"" + ganador + "\" ganó las predicciones!\n\n");
    }

}

