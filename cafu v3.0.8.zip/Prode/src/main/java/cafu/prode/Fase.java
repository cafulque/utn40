package cafu.prode;

public class Fase {

    private int fase;
    private String jugador;
    private Integer puntos;
    private int bonus;

    public Fase() {
        super();
    }

    public Fase(int fase, String jugador, Integer puntos, int bonus) {
        super();
        this.fase = fase;
        this.jugador = jugador;
        this.puntos = puntos;
        this.bonus = bonus;
    }

    // getter de Fase + Jugador + Puntos
    public PuntosFaseJugador getPuntosFaseJugador() {
        return new PuntosFaseJugador(fase, jugador, puntos, bonus);
    }

    // getters & setters
    public int getFase() {
        return fase;
    }

    public void setFase(int fase) {
        this.fase = fase;
    }

    public String getJugador() {
        return jugador;
    }

    public void setJugador(String jugador) {
        this.jugador = jugador;
    }

    public Integer getPuntos() {
        return puntos;
    }

    public void setPuntos(Integer puntos) {
        this.puntos = puntos;
    }

    public int getBonus() {
        return bonus;
    }

    public void setBonus(int bonus) {
        this.bonus = bonus;
    }

}

