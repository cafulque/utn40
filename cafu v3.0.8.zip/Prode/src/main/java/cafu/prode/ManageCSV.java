package cafu.prode;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.Map;
import java.util.List;
import java.util.TreeMap;

public class ManageCSV {

    // declaraciones
    public static List <String> lineasArchivo;

    public ManageCSV() {
        super();
    }

    // lee todas las filas de un archivo "csv"
    public static List <String> readRows(String archivo) {

        try {
            lineasArchivo = Files.readAllLines(Paths.get(archivo));
        } catch (IOException ex) {
            System.out.println("Imposible leer el archivo " + archivo);
            System.out.println("Por favor, comuníquese con el personal de sistemas!\n\n");
            System.exit(100);
        }

        return lineasArchivo;
    }

    // carga "resultados" en arreglos --> 1;Argentina;1;2;Arabia Saudita;1
    public static void loadResultados(List <String> lineasArchivo, Collection <Partido> partidos) {

        boolean header = true;
        String campos[];

        for (String fila : lineasArchivo) {

            if (header) header = false;
            else {
                campos = fila.split(";");
                Equipo equipo1 = new Equipo(campos[1]);
                Equipo equipo2 = new Equipo(campos[4]);
                Partido partido = new Partido(equipo1, equipo2);
                partido.setGolesEq1(Integer.parseInt(campos[2]));
                partido.setGolesEq2(Integer.parseInt(campos[3]));
                partido.setFase(Integer.parseInt(campos[0]));
                partidos.add(partido);
            }

        }

    }

    // carga "predicciones" en arreglos --> "Mariana;Argentina;X;;;Arabia Saudita;1"
    public static void loadPredicciones(List <String> lineasArchivo, Collection <Partido> partidos, 
                                        Map <String, Integer> puntosJugador,
                                        TreeMap <String, String> faseJugadorPuntos) {

        boolean header = true;
        int fase = 0, qtyPartidos = 1;                                  // para comparar fases, juegos/fase
        int puntos;                                                     // acierto/partido
        String clave, valor, jugador;                                   // Map --> clave, valor
        String campos[];

        for (String fila : lineasArchivo) {                             // Mariana;Argentina;X;;;Arabia Saudita;1

            if (header) header = false;
            else {

                campos = fila.split(";");                          // predicciones
                jugador = campos[0];                                    // jugador actual
                Equipo equipo1 = new Equipo(campos[1]);
                Equipo equipo2 = new Equipo(campos[5]);
                Partido partido = null;

                for (Partido partidoCol : partidos) {                   // loop resultados
                    if (partidoCol.getEquipo1().getNombre().equals(equipo1.getNombre())
                        && partidoCol.getEquipo2().getNombre().equals(equipo2.getNombre())) {
                        partido = partidoCol;
                        fase = partidoCol.getFase();
                    }
                }

                Equipo equipo = equipo1;
                LEV resultado = null;
                if ("X".equals(campos[2])) resultado = LEV.LOCAL;
                if ("X".equals(campos[3])) resultado = LEV.EMPATE;
                if ("X".equals(campos[4])) resultado = LEV.VISITANTE;

                // acumula puntos por jugador
                Predicciones forecast = new Predicciones(partido, equipo, resultado);
                puntos = forecast.puntos();                             // punto ganado/partido (0, 1)
                
                if (puntosJugador.containsKey(jugador)) {
                    puntosJugador.put(jugador, puntosJugador.get(jugador) + puntos);
                } else {
                    puntosJugador.put(jugador, puntos);
                }

                clave = jugador + ";" + fase + ";" + qtyPartidos++;     // Mariana;1;0 Mariana;1;1 ..
                valor = puntosJugador.get(jugador) + "";            // puntosAcumu;0
                faseJugadorPuntos.put(clave, valor);

            }

        }

    }

}

